require 'peatio/upstream/opendax'

Peatio::Upstream.registry[:opendax] = Peatio::Upstream::Opendax
