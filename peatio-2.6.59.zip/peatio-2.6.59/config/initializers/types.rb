ActiveRecord::Type.register(:uuid, UUID::Type)
