# encoding: UTF-8
# frozen_string_literal: true
# This file is auto-generated from the current state of VCS.
# Instead of editing this file, please use bin/gendocs.

module Peatio
  class Application
    GIT_TAG =    '2.6.0'
    GIT_SHA =    '66aceba'
    BUILD_DATE = '2019-11-07 11:43:58+00:00'
    VERSION =    GIT_TAG
  end
end
