## How to use Peatio with PostgreSQL

Export the following variables:

```bash
export DATABASE_ADAPTER="postgresql"
export DATABASE_PORT="5432"
export DATABASE_COLLATION=""
```
