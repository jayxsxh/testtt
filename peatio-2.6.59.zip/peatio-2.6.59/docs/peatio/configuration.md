# Peatio environments configuration
This document provides description of available configuration through the environment.

### General configuration
| Environment variable          | Default value | Possible values | Description                                                  |
| ----------------------------- | ------------- | --------------- | ------------------------------------------------------------ |
| `PEATIO_DEPOSIT_FUNDS_LOCKED` | false         | `true`, `false` | When turned on (`true`) user funds will be locked on deposit, and unlocked once the collection of this deposit succeed |
