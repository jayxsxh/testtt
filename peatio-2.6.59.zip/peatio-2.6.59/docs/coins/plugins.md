# List of coin plugins approved by RubyKube

* [Litecoin](https://github.com/rubykube/peatio-litecoin)
* [Ripple](https://github.com/rubykube/peatio-ripple)
* [Bicoin Cash](https://github.com/rubykube/peatio-bitcoincash)

## For plugin integration check doc/integration.md of specific plugin.
